<?php

namespace Packages\University\Controllers\API\v1;

use App\Http\Controllers\Controller;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Throwable;

/**
 * ============================================================================
 * BankPaymentApiController
 * ============================================================================
 * متحكم بوابة السداد الإلكتروني للبنوك.
 *
 * يوفر 4 نقاط نهاية (Endpoints):
 *   1) POST /tuition/getstudentinvoice  ← استعلام عن الرسوم الدراسية
 *   2) POST /tuition/payment            ← سداد الرسوم الدراسية
 *   3) POST /other/getstudentinvoice    ← استعلام عن الرسوم الأخرى
 *   4) POST /other/payment              ← سداد الرسوم الأخرى
 *
 * قاعدة أمنية: لا تُرجع تفاصيل الاستثناءات للبنك، فقط سجلها في logs.
 * قاعدة سلوكية: عند اكتمال سداد الرسوم الدراسية → حالة الطالب تصبح "مسجل".
 * ============================================================================
 */
class BankPaymentApiController extends Controller
{
    /**
     * جهات داخلية (منحة/تخفيض/تحويل/نقدي) ليست بنوكاً حقيقية،
     * فلا يجوز استخدام مفاتيحها للدخول من بوابة الدفع الإلكتروني.
     */
    private const INTERNAL_BANK_CODES = ['SCHOLARSHIP_BANK', 'DISCOUNT_BANK', 'INT_TRANSFER_BANK', 'CASH_BANK'];

    // ==================================================================
    // ============  دوال مساعدة  =======================================
    // ==================================================================

    /**
     * إرجاع رد فشل موحد بصيغة JSON.
     *
     * @param string $message نص عربي يشرح الخطأ للبنك.
     * @param int    $status  كود HTTP (400/401/403/404/409/422/500).
     */
    private function fail(string $message, int $status)
    {
        return response()->json(
            ['status' => false, 'message' => $message],
            $status,
            [],
            JSON_UNESCAPED_UNICODE, // لا تُرمِّز الحروف العربية لـ \uXXXX
        );
    }

    /**
     * معالج الأخطاء الداخلية (500).
     * نسجل التفاصيل الكاملة في logs للأمان، ونُرجع رسالة عامة للبنك
     * لتجنّب تسريب بنية قاعدة البيانات أو SQL.
     */
    private function serverError(Throwable $e, string $context)
    {
        Log::error("BankPayment[$context]: " . $e->getMessage(), [
            'trace' => $e->getTraceAsString(),
        ]);
        return $this->fail('حدث خطأ داخلي في الخادم. يرجى المحاولة لاحقاً.', 500);
    }

    /**
     * استخراج مفتاح API من الطلب.
     * يقبله من حقل api_key في الـ Body أو من هيدر X-API-KEY.
     */
    private function getApiKey(Request $request): ?string
    {
        return $request->input('api_key') ?? $request->header('X-API-KEY');
    }

    /**
     * التحقق من صحة مفتاح البنك.
     *
     * الشروط الثلاثة:
     *   1. المفتاح موجود في جدول banks.
     *   2. is_active = 1 (البنك مفعّل).
     *   3. code ليس من البنوك الداخلية (منحة/تخفيض/...).
     *
     * @return object|null سجل البنك عند النجاح، أو null عند الفشل.
     */
    private function validateApiKey(?string $apiKey)
    {
        if (empty($apiKey)) {
            return null;
        }

        return DB::table('banks')
            ->where('api_key', $apiKey)
            ->where('is_active', 1)
            ->whereNotIn('code', self::INTERNAL_BANK_CODES)
            ->first();
    }

    /**
     * جلب بيانات الطالب عبر الرقم الجامعي.
     * نضم جدول academic_statuses لمعرفة هل حالته "موقفة للقيد" (is_hold=1).
     */
    private function findStudent($unNo)
    {
        return DB::table('students as s')
            ->leftJoin('academic_statuses as st', 's.current_academic_status_id', '=', 'st.id')
            ->where('s.university_no', $unNo)
            ->select('s.*', 'st.is_hold as status_hold')
            ->first();
    }

    /**
     * حساب إجمالي المبلغ المدفوع فعلياً على فاتورة معيّنة.
     * الفلترة على:
     *   - invoice_id محدد
     *   - status = 'approved' (تجاهل payments المرفوضة)
     *   - is_cancelled = 0 (تجاهل الملغاة)
     */
    private function totalPaid(int $invoiceId): float
    {
        return round(
            (float) DB::table('payments')
                ->where('invoice_id', $invoiceId)
                ->where('status', 'approved')
                ->where('is_cancelled', 0)
                ->sum('amount'),
            2,
        );
    }

    /**
     * جلب id العملة SDG (الجنيه السوداني).
     * احتياطي: 1 إذا لم توجد (حماية من انهيار الكود).
     */
    private function sdgCurrencyId(): int
    {
        return (int) (DB::table('currencies')->where('code', 'SDG')->value('id') ?? 1);
    }

    /**
     * ================================================================
     * تحويل الحالة الأكاديمية إلى "مسجل" عند اكتمال السداد
     * ================================================================
     * الشرط:
     *   - كل الفواتير النشطة (is_active=1) للطالب لها payment_status='paid'.
     *
     * الخطوات:
     *   1) التحقق من وجود فاتورة نشطة واحدة على الأقل (لا نُفعّل من لا فواتير له).
     *   2) التحقق من عدم وجود فاتورة نشطة غير مسددة.
     *   3) جلب id الحالة "مسجل" عبر كودها REG (أكثر أماناً من id=1 ثابت).
     *   4) تحديث students.current_academic_status_id + is_active.
     *
     * @return bool true إذا حُدّثت الحالة، false إن لم يُستوفَ الشرط.
     */
    private function refreshStudentAcademicStatusIfFullyPaid(int $studentId): bool
    {
        // (1) هل هناك فاتورة نشطة على الأقل؟
        $hasAnyActive = DB::table('invoices')->where('student_id', $studentId)->where('is_active', 1)->exists();

        if (!$hasAnyActive) {
            return false;
        }

        // (2) هل ما زالت هناك فاتورة نشطة غير مسددة؟
        $hasUnpaid = DB::table('invoices')
            ->where('student_id', $studentId)
            ->where('is_active', 1)
            ->where('payment_status', '!=', 'paid')
            ->exists();

        if ($hasUnpaid) {
            return false;
        }

        // (3) اجلب id حالة "مسجل" (code = REG). الافتراضي 1 كاحتياط.
        $registeredStatusId = (int) (DB::table('academic_statuses')->where('code', 'REG')->value('id') ?? 1);

        // (4) حدّث حالة الطالب (أكاديمياً + تفعيل الحساب)
        DB::table('students')
            ->where('id', $studentId)
            ->update([
                'current_academic_status_id' => $registeredStatusId,
                'is_active' => 1,
                'updated_at' => now(),
            ]);

        return true;
    }

    /**
     * التحقق من مدخلات بوابة السداد (تُستخدم في tuition و other).
     * - يدمج Amount/amount في مفتاح واحد (Amount).
     * - يقرأ api_key من Body أو Header.
     * - invoice_id = 0 مسموح = سداد مجمّع (يُستخدم في tuition فقط).
     */
    private function validatePayment(Request $request)
    {
        $data = $request->all();
        $data['Amount'] = $request->input('Amount', $request->input('amount'));
        $data['api_key'] = $this->getApiKey($request);

        return Validator::make(
            $data,
            [
                'invoice_id' => 'required|integer|min:0',
                'university_no' => 'required|integer|min:1',
                'Amount' => 'required|numeric|gt:0',
                'esal_no' => 'required|string|max:50',
                'esal_date' => 'required|date',
                'api_key' => 'required|string',
            ],
            [],
            [
                'invoice_id' => 'invoice_id',
                'university_no' => 'university_no',
                'Amount' => 'Amount',
                'esal_no' => 'esal_no',
                'esal_date' => 'esal_date',
                'api_key' => 'api_key',
            ],
        );
    }

    // ==================================================================
    // ============  1. بوابات الرسوم الدراسية  =========================
    // ==================================================================

    /**
     * POST /api/v1/tuition/getstudentinvoice
     * ---------------------------------------
     * استعلام عن كل فواتير الرسوم الدراسية المستحقة للطالب.
     *
     * المدخلات: university_no، api_key.
     * المخرجات: بيانات الطالب + الإجمالي المتبقي + تفاصيل كل فاتورة.
     *
     * كود الخطأ:
     *   400: مدخلات ناقصة أو لا فواتير مستحقة
     *   401: api_key خاطئ
     *   403: الطالب موقوف/غير نشط
     *   404: الطالب أو الفاتورة غير موجودة
     */
    public function getStudentTuitionInvoice(Request $request)
    {
        try {
            // ---------- (أ) التحقق من المدخلات الأساسية ----------
            $unNo = $request->input('university_no');
            $apiKey = $this->getApiKey($request);

            if (!$unNo || !is_numeric($unNo) || !$apiKey) {
                return $this->fail('جميع المتغيرات المطلوبة غير مكتملة أو غير صحيحة (university_no, api_key).', 400);
            }

            // ---------- (ب) التحقق من مفتاح البنك ----------
            $bank = $this->validateApiKey($apiKey);
            if (!$bank) {
                return $this->fail('مفتاح التحقق (api_key) غير صحيح أو غير مصرح له.', 401);
            }

            // ---------- (ج) جلب الطالب ----------
            $student = $this->findStudent($unNo);
            if (!$student) {
                return $this->fail(
                    'عذراً، الرقم الجامعي غير موجود بالنظام. يرجى التأكد من الرقم والمحاولة مرة أخرى.',
                    404,
                );
            }

            // ---------- (د) التحقق من حالة الطالب الأكاديمية ----------
            //     is_active=0 أو is_hold=1 (منسحب/مفصول/موقوف/خريج) → مرفوض
            if (!$student->is_active || (int) $student->status_hold === 1) {
                return $this->fail(
                    'حساب الطالب غير نشط حالياً. الرجاء مراجعة مسجل الكلية لمعالجة الحالة الأكاديمية.',
                    403,
                );
            }

            // ---------- (هـ) جلب كل الفواتير النشطة غير المسددة ----------
            //     نُعيد كل الفواتير (وليس آخر واحدة) لأن البنك قد يحتاج
            //     عرض إجمالي المديونية للطالب.
            $invoices = DB::table('invoices')
                ->where('student_id', $student->id)
                ->where('is_active', 1)
                ->where('payment_status', '!=', 'paid')
                ->orderByDesc('id')
                ->get();

            // لا توجد فواتير إطلاقاً؟
            if ($invoices->isEmpty()) {
                $hasAnyInvoice = DB::table('invoices')->where('student_id', $student->id)->exists();
                if (!$hasAnyInvoice) {
                    return $this->fail(
                        'لا توجد فاتورة رسوم مطالب بها هذا الطالب حالياً. الرجاء مراجعة المسجل الإداري.',
                        404,
                    );
                }
                // توجد فواتير لكن كلها مسددة أو ملغاة
                return $this->fail('تم سداد فواتير هذا الطالب بالكامل أو جميع الفواتير ملغاة/معلقة.', 400);
            }

            // ---------- (و) حساب المتبقي لكل فاتورة + الإجمالي ----------
            //     نتجاهل أي فاتورة رصيدها الفعلي صفر (payment_status لم يُحدَّث).
            $invoicesDetails = [];
            $totalRemaining = 0.0;

            foreach ($invoices as $inv) {
                $paid = $this->totalPaid($inv->id);
                $remaining = round((float) $inv->amount - $paid, 2);

                if ($remaining <= 0) {
                    continue; // فاتورة مدفوعة فعلياً، تجاهلها
                }

                $invoicesDetails[] = [
                    'invoice_id' => (int) $inv->id,
                    'study_year_id' => (int) $inv->study_year_id,
                    'semester_id' => (int) ($inv->semester_id ?? 0),
                    'college_id' => (int) ($inv->college_id ?? 0),
                    'level_id' => (int) ($inv->level_id ?? 0),
                    'registration_fees' => (float) $inv->registration_fees,
                    'tuition_fees' => (float) $inv->tuition_fees,
                    'late_fees' => (float) $inv->late_fees,
                    'fine_fees' => (float) $inv->fine_fees,
                    'total_amount' => (float) $inv->amount,
                    'paid_amount' => $paid,
                    'remaining_amount' => $remaining,
                    'payment_status' => (string) $inv->payment_status,
                    'created_at' => $inv->created_at,
                    'updated_at' => $inv->updated_at,
                ];

                $totalRemaining += $remaining;
            }

            $totalRemaining = round($totalRemaining, 2);

            if ($totalRemaining <= 0) {
                return $this->fail('تم استيفاء كامل مبلغ جميع الفواتير. يرجى مراجعة المسجل لتحديث الحالة.', 400);
            }

            // ---------- (ز) الفاتورة المرجعية للأسماء العامة ----------
            $firstInvoice = $invoices->first();

            $college = $firstInvoice->college_id ? DB::table('colleges')->find($firstInvoice->college_id) : null;
            $level = $firstInvoice->level_id ? DB::table('levels')->find($firstInvoice->level_id) : null;
            $currency = DB::table('currencies')->find($firstInvoice->currency_id);
            $department = DB::table('departments')->find($student->department_id);

            // ---------- (ح) إجماليات كل بند (مجموع كل الفواتير) ----------
            $sumRegFees = round((float) $invoices->sum('registration_fees'), 2);
            $sumStudyFees = round((float) $invoices->sum('tuition_fees'), 2);
            $sumLateFees = round((float) $invoices->sum('late_fees'), 2);
            $sumFineFees = round((float) $invoices->sum('fine_fees'), 2);

            // نسبة الغرامة = إجمالي الغرامات ÷ إجمالي الرسوم الدراسية
            $finePercentage = $sumStudyFees > 0 ? round(($sumFineFees / $sumStudyFees) * 100, 2) : 0.0;

            // ---------- (ط) الرد النهائي ----------
            return response()->json(
                [
                    'invoice_id' => (int) $firstInvoice->id, // مرجعي فقط
                    'university_no' => (string) $student->university_no,
                    'bank_name' => (string) $bank->name,
                    'year_id' => (int) $firstInvoice->study_year_id,
                    'student_name_arabic' => (string) $student->full_name,
                    'college_name_arabic' => (string) ($college->name ?? ''),
                    'department_name_arabic' => (string) ($department->name ?? ''),
                    'class_name_arabic' => (string) ($level->name ?? ''),
                    'currency_name' => (string) ($currency->name ?? 'جنيه'),
                    'currency_name_en' => (string) ($currency->code ?? 'SDG'),
                    'curr_id' => 0, // ثابت حسب مواصفة البنك
                    'class_id' => (int) ($firstInvoice->level_id ?? 0),
                    'department_id' => (int) $student->department_id,

                    // إجماليات بنود الفواتير
                    'reg_fees' => $sumRegFees,
                    'study_fees' => $sumStudyFees,
                    'late_fees' => $sumLateFees,
                    'fine_fees' => $sumFineFees,

                    // الإجمالي المتبقي على الطالب (هذا هو المبلغ المستحق)
                    'amount' => $totalRemaining,
                    'invoices_count' => count($invoicesDetails),

                    'college_code' => is_numeric($college->code ?? null)
                        ? (int) $college->code
                        : (int) ($firstInvoice->college_id ?? 0),
                    'reg_status' => 1,
                    'created_at' => $firstInvoice->created_at,
                    'updated_at' => $firstInvoice->updated_at,
                    'fine_percentage' => $finePercentage,

                    // قائمة تفصيلية بكل فاتورة
                    'invoices_details' => $invoicesDetails,
                ],
                200,
                [],
                JSON_UNESCAPED_UNICODE,
            );
        } catch (Throwable $e) {
            return $this->serverError($e, 'tuition.inquiry');
        }
    }

    /**
     * POST /api/v1/tuition/payment
     * -----------------------------
     * تنفيذ سداد الرسوم الدراسية.
     *
     * حالة (1) invoice_id = 0 → سداد مجمّع لكل الفواتير غير المسددة.
     * حالة (2) invoice_id > 0 → سداد فاتورة واحدة محددة.
     *
     * عند النجاح واكتمال السداد → تحويل حالة الطالب الأكاديمية إلى "مسجل".
     *
     * كود الخطأ:
     *   400: مدخلات خاطئة / فاتورة ملغاة / مدفوعة مسبقاً
     *   401: api_key خاطئ
     *   403: الفاتورة لا تخص الطالب
     *   404: الطالب/الفاتورة غير موجودة
     *   409: رقم الإيصال مستخدم (تكرار متزامن)
     *   422: المبلغ أكبر من المتبقي
     */
    public function processTuitionPayment(Request $request)
    {
        try {
            // ---------- (1) التحقق من المدخلات ----------
            $v = $this->validatePayment($request);
            if ($v->fails()) {
                return $this->fail('بيانات غير مكتملة أو غير صحيحة: ' . implode(' | ', $v->errors()->all()), 400);
            }

            // ---------- (2) استخراج القيم ----------
            $invoiceId = (int) $request->input('invoice_id');
            $unNo = $request->input('university_no');
            $amount = round((float) $request->input('Amount', $request->input('amount')), 2);
            $esalNo = (string) $request->input('esal_no');
            $esalDate = date('Y-m-d', strtotime($request->input('esal_date')));

            // ---------- (3) التحقق من البنك ----------
            $bank = $this->validateApiKey($this->getApiKey($request));
            if (!$bank) {
                return $this->fail('مفتاح التحقق (api_key) غير صحيح أو غير مصرح له.', 401);
            }

            // ---------- (4) منع تكرار رقم الإيصال ----------
            if (DB::table('payments')->where('receipt_no', $esalNo)->exists()) {
                return $this->fail('عذراً، رقم الإيصال مستخدم في عملية سداد سابقة.', 409);
            }

            // ---------- (5) جلب الطالب ----------
            $student = $this->findStudent($unNo);
            if (!$student) {
                return $this->fail('الرقم الجامعي غير موجود بالنظام. الرجاء مراجعة المسجل.', 404);
            }

            // ---------- (6) تنفيذ السداد داخل معاملة ----------
            return DB::transaction(function () use ($student, $bank, $invoiceId, $amount, $esalNo, $esalDate) {
                // =========================================================
                // الحالة (1): سداد مجمّع لكل الفواتير
                // =========================================================
                if ($invoiceId === 0) {
                    // اقفل كل الفواتير غير المسددة لمنع سدادين متزامنين
                    $invoices = DB::table('invoices')
                        ->where('student_id', $student->id)
                        ->where('is_active', 1)
                        ->where('payment_status', '!=', 'paid')
                        ->orderBy('id')
                        ->lockForUpdate()
                        ->get();

                    if ($invoices->isEmpty()) {
                        return $this->fail('لا توجد فواتير مستحقة لهذا الطالب.', 404);
                    }

                    // احسب المتبقي الإجمالي
                    $totalRemaining = 0.0;
                    foreach ($invoices as $inv) {
                        $totalRemaining += max(0, (float) $inv->amount - $this->totalPaid($inv->id));
                    }
                    $totalRemaining = round($totalRemaining, 2);

                    if ($totalRemaining <= 0) {
                        return $this->fail('تم استيفاء كامل مبلغ الفواتير.', 400);
                    }

                    // المبلغ يجب أن يطابق الإجمالي (سداد مجمّع = سداد كامل)
                    if (abs($amount - $totalRemaining) > 0.001) {
                        return $this->fail("المبلغ المدفوع ($amount) لا يطابق إجمالي المستحق ($totalRemaining).", 422);
                    }

                    // وزّع المبلغ على الفواتير بالترتيب
                    $remainingToDistribute = $amount;

                    foreach ($invoices as $inv) {
                        if ($remainingToDistribute <= 0) {
                            break;
                        }

                        $invPaid = $this->totalPaid($inv->id);
                        $invRemaining = round((float) $inv->amount - $invPaid, 2);
                        if ($invRemaining <= 0) {
                            continue;
                        }

                        $payNow = min($invRemaining, $remainingToDistribute);

                        // أضف سجل دفع لكل فاتورة (رقم إيصال فريد لكل واحدة)
                        DB::table('payments')->insert([
                            'receipt_no' => $esalNo . '-' . $inv->id,
                            'student_id' => $student->id,
                            'invoice_id' => $inv->id,
                            'study_year_id' => $inv->study_year_id,
                            'semester_id' => $inv->semester_id,
                            'currency_id' => $inv->currency_id,
                            'bank_id' => $bank->id,
                            'amount' => $payNow,
                            'payment_date' => $esalDate,
                            'status' => 'approved',
                            'notes' => 'سداد إلكتروني عبر البنك (مجمّع) - إيصال: ' . $esalNo,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);

                        // حدّث حالة الفاتورة
                        $newPaid = round($invPaid + $payNow, 2);
                        $newRemaining = round((float) $inv->amount - $newPaid, 2);
                        $newStatus = $newRemaining <= 0 ? 'paid' : 'partially_paid';

                        DB::table('invoices')
                            ->where('id', $inv->id)
                            ->update([
                                'payment_status' => $newStatus,
                                'updated_at' => now(),
                            ]);

                        $remainingToDistribute -= $payNow;
                    }

                    // ✅ عند اكتمال كل الفواتير → حوّل الحالة إلى "مسجل"
                    $this->refreshStudentAcademicStatusIfFullyPaid($student->id);

                    return response()->json(
                        [
                            'status' => true,
                            'message' => 'تم استلام وتأكيد السداد المجمّع لجميع الفواتير المستحقة بنجاح.',
                            'esal_no' => $esalNo,
                            'paid_amount' => $amount,
                        ],
                        200,
                        [],
                        JSON_UNESCAPED_UNICODE,
                    );
                }

                // =========================================================
                // الحالة (2): سداد فاتورة واحدة
                // =========================================================
                $invoice = DB::table('invoices')->where('id', $invoiceId)->lockForUpdate()->first();

                if (!$invoice) {
                    return $this->fail('الفاتورة غير موجودة. الرجاء مراجعة الإدارة المالية.', 404);
                }
                if ((int) $invoice->student_id !== (int) $student->id) {
                    return $this->fail('الفاتورة لا تخص هذا الرقم الجامعي.', 403);
                }
                if (!$invoice->is_active) {
                    return $this->fail('الفاتورة ملغاة أو معلقة. الرجاء مراجعة مسجل الكلية.', 400);
                }
                if ($invoice->payment_status === 'paid') {
                    return $this->fail('عملية مرفوضة: هذه الفاتورة تم سدادها بالكامل سابقاً.', 400);
                }

                // احسب المتبقي على الفاتورة
                $remaining = round((float) $invoice->amount - $this->totalPaid($invoice->id), 2);
                if ($remaining <= 0) {
                    return $this->fail('تم استيفاء كامل مبلغ الفاتورة.', 400);
                }
                if ($amount > $remaining) {
                    return $this->fail("المبلغ المدفوع ($amount) أكبر من المتبقي ($remaining).", 422);
                }

                // سجّل الدفعة
                DB::table('payments')->insert([
                    'receipt_no' => $esalNo,
                    'student_id' => $student->id,
                    'invoice_id' => $invoice->id,
                    'study_year_id' => $invoice->study_year_id,
                    'semester_id' => $invoice->semester_id,
                    'currency_id' => $invoice->currency_id,
                    'bank_id' => $bank->id,
                    'amount' => $amount,
                    'payment_date' => $esalDate,
                    'status' => 'approved',
                    'notes' => 'سداد إلكتروني عبر البنك - إيصال: ' . $esalNo,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                // حدّث حالة الفاتورة
                $payStatus = $amount >= $remaining ? 'paid' : 'partially_paid';

                DB::table('invoices')
                    ->where('id', $invoice->id)
                    ->update([
                        'payment_status' => $payStatus,
                        'updated_at' => now(),
                    ]);

                // ✅ تحقق: إن كانت هذه آخر فاتورة → حوّل الحالة إلى "مسجل"
                $this->refreshStudentAcademicStatusIfFullyPaid($student->id);

                return response()->json(
                    [
                        'status' => true,
                        'message' => 'تم استلام وتأكيد سداد الرسوم الدراسية بنجاح.',
                        'invoice_id' => (int) $invoice->id,
                        'esal_no' => $esalNo,
                        'paid_amount' => $amount,
                    ],
                    200,
                    [],
                    JSON_UNESCAPED_UNICODE,
                );
            });
        } catch (QueryException $e) {
            // 23000 = خطأ تكامل مرجعي (تكرار receipt_no كـ PRIMARY KEY)
            if ($e->getCode() === '23000') {
                return $this->fail('عذراً، رقم الإيصال مستخدم في عملية سداد سابقة.', 409);
            }
            return $this->serverError($e, 'tuition.payment');
        } catch (Throwable $e) {
            return $this->serverError($e, 'tuition.payment');
        }
    }

    // ==================================================================
    // ============  2. بوابات الرسوم والخدمات الأخرى  =================
    // ==================================================================

    /**
     * POST /api/v1/other/getstudentinvoice
     * -------------------------------------
     * استعلام عن كل الرسوم الأخرى غير المسددة للطالب.
     * الرسوم الأخرى = (رسوم نشاط، تأمين صحي، كرت جامعي، سكن، نقل، مكتبة...).
     *
     * الفرق عن الرسوم الدراسية:
     *   - لا توجد فواتير (invoices) هنا، بل سجلات في other_fees مباشرة.
     *   - السداد يجب أن يكون مطابقاً للإجمالي تماماً.
     */
    public function getStudentOtherInvoice(Request $request)
    {
        try {
            // ---------- (أ) التحقق من المدخلات ----------
            $unNo = $request->input('university_no');
            $apiKey = $this->getApiKey($request);

            if (!$unNo || !is_numeric($unNo) || !$apiKey) {
                return $this->fail('جميع المتغيرات المطلوبة غير مكتملة أو غير صحيحة (university_no, api_key).', 400);
            }

            // ---------- (ب) التحقق من البنك ----------
            $bank = $this->validateApiKey($apiKey);
            if (!$bank) {
                return $this->fail('مفتاح التحقق (api_key) غير صحيح أو غير مصرح له.', 401);
            }

            // ---------- (ج) جلب الطالب ----------
            $student = $this->findStudent($unNo);
            if (!$student) {
                return $this->fail('الرقم الجامعي غير موجود بالنظام. يرجى مراجعة مسجل الكلية.', 404);
            }

            // ---------- (د) جلب كل الرسوم الأخرى غير المدفوعة ----------
            $otherFees = DB::table('other_fees')
                ->join('other_fee_types', 'other_fees.other_fee_type_id', '=', 'other_fee_types.id')
                ->where('other_fees.student_id', $student->id)
                ->where('other_fees.is_paid', 0)
                ->orderBy('other_fees.id')
                ->select(
                    'other_fees.id as fee_id',
                    'other_fees.study_year_id',
                    'other_fees.semester_id',
                    'other_fee_types.name as fee_name',
                    'other_fees.amount',
                    'other_fees.created_at',
                    'other_fees.updated_at',
                )
                ->get();

            if ($otherFees->isEmpty()) {
                return $this->fail('لا توجد رسوم أو مطالبات خدمية مستحقة على هذا الطالب. الرجاء مراجعة المسجل.', 404);
            }

            // ---------- (هـ) الإجمالي ----------
            $totalAmount = round((float) $otherFees->sum('amount'), 2);
            $countFees = $otherFees->count();

            $firstFee = $otherFees->first();
            $department = DB::table('departments')->find($student->department_id);
            $college = DB::table('colleges')->find($student->college_id);

            // ---------- (و) الرد ----------
            return response()->json(
                [
                    'invoice_id' => (int) $firstFee->fee_id, // مرجعي (أول رسم)
                    'university_no' => (string) $student->university_no,
                    'bank_name' => (string) $bank->name,
                    'year_id' => (int) $firstFee->study_year_id,
                    'student_name_arabic' => (string) $student->full_name,
                    'college_name_arabic' => (string) ($college->name ?? 'خدمات ورسوم أخرى'),
                    'department_name_arabic' => (string) ($department->name ?? 'شؤون الطلاب'),
                    'class_name_arabic' => 'عام',
                    'currency_name' => 'جنيه',
                    'currency_name_en' => 'SDG',
                    'curr_id' => 0,
                    'class_id' => 0,
                    'department_id' => (int) $student->department_id,

                    // الرسوم الدراسية لا تنطبق في هذه البوابة
                    'reg_fees' => 0,
                    'study_fees' => 0,
                    'late_fees' => 0,
                    'fine_fees' => 0,

                    // الإجمالي = مجموع كل الرسوم الأخرى
                    'amount' => $totalAmount,
                    'fees_count' => $countFees,

                    'college_code' => is_numeric($college->code ?? null)
                        ? (int) $college->code
                        : (int) $student->college_id,
                    'reg_status' => 2, // 2 = رسوم خدمات (تمييز عن 1 = دراسية)
                    'created_at' => $firstFee->created_at,
                    'updated_at' => $firstFee->updated_at,
                    'fine_percentage' => 0,

                    // قائمة الرسوم التفصيلية
                    'services_details' => $otherFees,
                ],
                200,
                [],
                JSON_UNESCAPED_UNICODE,
            );
        } catch (Throwable $e) {
            return $this->serverError($e, 'other.inquiry');
        }
    }

    /**
     * POST /api/v1/other/payment
     * ---------------------------
     * تنفيذ سداد الرسوم الأخرى.
     *
     * ملاحظات مهمة:
     *   - لا يوجد سداد جزئي هنا: المبلغ يجب أن يطابق الإجمالي تماماً.
     *   - invoice_id الممرر = id أول رسم (كما رجعه الاستعلام).
     *   - عند النجاح: تُحدَّث كل الرسوم is_paid = 1 في عملية واحدة.
     */
    public function processOtherPayment(Request $request)
    {
        try {
            // ---------- (1) التحقق من المدخلات ----------
            $v = $this->validatePayment($request);
            if ($v->fails()) {
                return $this->fail('بيانات غير مكتملة أو غير صحيحة: ' . implode(' | ', $v->errors()->all()), 400);
            }

            // ---------- (2) استخراج القيم ----------
            $invoiceId = (int) $request->input('invoice_id');
            $unNo = $request->input('university_no');
            $amount = round((float) $request->input('Amount', $request->input('amount')), 2);
            $esalNo = (string) $request->input('esal_no');
            $esalDate = date('Y-m-d', strtotime($request->input('esal_date')));

            // ---------- (3) التحقق من البنك ----------
            $bank = $this->validateApiKey($this->getApiKey($request));
            if (!$bank) {
                return $this->fail('مفتاح التحقق (api_key) غير صحيح أو غير مصرح له.', 401);
            }

            // ---------- (4) منع تكرار رقم الإيصال ----------
            if (DB::table('payments')->where('receipt_no', $esalNo)->exists()) {
                return $this->fail('عذراً، رقم الإيصال مستخدم سابقاً.', 409);
            }

            // ---------- (5) جلب الطالب ----------
            $student = $this->findStudent($unNo);
            if (!$student) {
                return $this->fail('الرقم الجامعي غير موجود. يرجى مراجعة مسجل الكلية.', 404);
            }

            // ---------- (6) تنفيذ السداد داخل معاملة ----------
            return DB::transaction(function () use ($student, $bank, $invoiceId, $amount, $esalNo, $esalDate) {
                // اقفل كل رسوم الطالب غير المدفوعة (لمنع تزامن)
                $fees = DB::table('other_fees')
                    ->where('student_id', $student->id)
                    ->where('is_paid', 0)
                    ->orderBy('id')
                    ->lockForUpdate()
                    ->get();

                if ($fees->isEmpty()) {
                    return $this->fail('لا توجد رسوم خدمية مستحقة على هذا الطالب.', 404);
                }

                // invoice_id في هذه البوابة = رقم أول رسم (كما أرجعه الاستعلام)
                if (!$fees->contains('id', $invoiceId)) {
                    return $this->fail('رقم الفاتورة غير صحيح أو سُدد سابقاً.', 404);
                }

                // المبلغ يجب أن يطابق الإجمالي (لا سداد جزئي هنا)
                $total = round((float) $fees->sum('amount'), 2);
                if (abs($amount - $total) > 0.001) {
                    return $this->fail("المبلغ المدفوع ($amount) لا يطابق إجمالي المستحق ($total).", 422);
                }

                $first = $fees->first();

                // علّم كل الرسوم كمدفوعة
                DB::table('other_fees')
                    ->whereIn('id', $fees->pluck('id'))
                    ->update([
                        'is_paid' => 1,
                        'updated_at' => now(),
                    ]);

                // سجّل الدفعة (invoice_id = null لأنها رسوم خدمات)
                DB::table('payments')->insert([
                    'receipt_no' => $esalNo,
                    'student_id' => $student->id,
                    'invoice_id' => null,
                    'study_year_id' => $first->study_year_id,
                    'semester_id' => $first->semester_id ?? (int) DB::table('semesters')->orderBy('id')->value('id'),
                    'currency_id' => $this->sdgCurrencyId(),
                    'bank_id' => $bank->id,
                    'amount' => $amount,
                    'payment_date' => $esalDate,
                    'status' => 'approved',
                    'notes' => 'سداد خدمات ورسوم أخرى - إيصال: ' . $esalNo,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                return response()->json(
                    [
                        'status' => true,
                        'message' => 'تم استلام وتأكيد سداد الرسوم  بنجاح.',
                        'esal_no' => $esalNo,
                        'paid_amount' => $amount,
                    ],
                    200,
                    [],
                    JSON_UNESCAPED_UNICODE,
                );
            });
        } catch (QueryException $e) {
            if ($e->getCode() === '23000') {
                return $this->fail('عذراً، رقم الإيصال مستخدم سابقاً.', 409);
            }
            return $this->serverError($e, 'other.payment');
        } catch (Throwable $e) {
            return $this->serverError($e, 'other.payment');
        }
    }
}
